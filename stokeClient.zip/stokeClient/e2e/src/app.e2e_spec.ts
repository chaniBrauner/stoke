'use strict'; // necessary for es6 output in node

import { browser, element, by, ElementFinder, ElementArrayFinder } from 'protractor';
import { promise } from 'selenium-webdriver';

const expectedH1 = 'Tour of Products';
const expectedTitle = `${expectedH1}`;
const targetProduct = { id: 15, name: 'Magneta' };
const targetProductDashboardIndex = 3;
const nameSuffix = 'X';
const newProductName = targetProduct.name + nameSuffix;

class Product {
  id: number;
  name: string;

  // Factory methods

  // Product from string formatted as '<id> <name>'.
  static fromString(s: string): Product {
    return {
      id: +s.substr(0, s.indexOf(' ')),
      name: s.substr(s.indexOf(' ') + 1),
    };
  }

  // Product from product list <li> element.
  static async fromLi(li: ElementFinder): Promise<Product> {
    let stringsFromA = await li.all(by.css('a')).getText();
    let strings = stringsFromA[0].split(' ');
    return { id: +strings[0], name: strings[1] };
  }

  // Product id and name from the given detail element.
  static async fromDetail(detail: ElementFinder): Promise<Product> {
    // Get product id from the first <div>
    let _id = await detail.all(by.css('div')).first().getText();
    // Get name from the h2
    let _name = await detail.element(by.css('h2')).getText();
    return {
      id: +_id.substr(_id.indexOf(' ') + 1),
      name: _name.substr(0, _name.lastIndexOf(' '))
    };
  }
}

describe('Tutorial part 6', () => {

  beforeAll(() => browser.get(''));

  function getPageElts() {
    let navElts = element.all(by.css('app-root nav a'));

    return {
      navElts: navElts,

      appDashboardHref: navElts.get(0),
      appDashboard: element(by.css('app-root app-dashboard')),
      topProducts: element.all(by.css('app-root app-dashboard > div h4')),

      appProductsHref: navElts.get(1),
      appProducts: element(by.css('app-root app-products')),
      allProducts: element.all(by.css('app-root app-products li')),
      selectedProductSubview: element(by.css('app-root app-products > div:last-child')),

      productDetail: element(by.css('app-root app-product-detail > div')),

      searchBox: element(by.css('#search-box')),
      searchResults: element.all(by.css('.search-result li'))
    };
  }

  describe('Initial page', () => {

    it(`has title '${expectedTitle}'`, () => {
      expect(browser.getTitle()).toEqual(expectedTitle);
    });

    it(`has h1 '${expectedH1}'`, () => {
      expectHeading(1, expectedH1);
    });

    const expectedViewNames = ['Dashboard', 'Products'];
    it(`has views ${expectedViewNames}`, () => {
      let viewNames = getPageElts().navElts.map((el: ElementFinder) => el.getText());
      expect(viewNames).toEqual(expectedViewNames);
    });

    it('has dashboard as the active view', () => {
      let page = getPageElts();
      expect(page.appDashboard.isPresent()).toBeTruthy();
    });

  });

  describe('Dashboard tests', () => {

    beforeAll(() => browser.get(''));

    it('has top products', () => {
      let page = getPageElts();
      expect(page.topProducts.count()).toEqual(4);
    });

    it(`selects and routes to ${targetProduct.name} details`, dashboardSelectTargetProduct);

    it(`updates product name (${newProductName}) in details view`, updateProductNameInDetailView);

    it(`cancels and shows ${targetProduct.name} in Dashboard`, () => {
      element(by.buttonText('go back')).click();
      browser.waitForAngular(); // seems necessary to gets tests to pass for toh-pt6

      let targetProductElt = getPageElts().topProducts.get(targetProductDashboardIndex);
      expect(targetProductElt.getText()).toEqual(targetProduct.name);
    });

    it(`selects and routes to ${targetProduct.name} details`, dashboardSelectTargetProduct);

    it(`updates product name (${newProductName}) in details view`, updateProductNameInDetailView);

    it(`saves and shows ${newProductName} in Dashboard`, () => {
      element(by.buttonText('save')).click();
      browser.waitForAngular(); // seems necessary to gets tests to pass for toh-pt6

      let targetProductElt = getPageElts().topProducts.get(targetProductDashboardIndex);
      expect(targetProductElt.getText()).toEqual(newProductName);
    });

  });

  describe('Products tests', () => {

    beforeAll(() => browser.get(''));

    it('can switch to Products view', () => {
      getPageElts().appProductsHref.click();
      let page = getPageElts();
      expect(page.appProducts.isPresent()).toBeTruthy();
      expect(page.allProducts.count()).toEqual(10, 'number of products');
    });

    it('can route to product details', async () => {
      getProductLiEltById(targetProduct.id).click();

      let page = getPageElts();
      expect(page.productDetail.isPresent()).toBeTruthy('shows product detail');
      let product = await Product.fromDetail(page.productDetail);
      expect(product.id).toEqual(targetProduct.id);
      expect(product.name).toEqual(targetProduct.name.toUpperCase());
    });

    it(`updates product name (${newProductName}) in details view`, updateProductNameInDetailView);

    it(`shows ${newProductName} in Products list`, () => {
      element(by.buttonText('save')).click();
      browser.waitForAngular();
      let expectedText = `${targetProduct.id} ${newProductName}`;
      expect(getProductAEltById(targetProduct.id).getText()).toEqual(expectedText);
    });

    it(`deletes ${newProductName} from Products list`, async () => {
      const productsBefore = await toProductArray(getPageElts().allProducts);
      const li = getProductLiEltById(targetProduct.id);
      li.element(by.buttonText('x')).click();

      const page = getPageElts();
      expect(page.appProducts.isPresent()).toBeTruthy();
      expect(page.allProducts.count()).toEqual(9, 'number of products');
      const productsAfter = await toProductArray(page.allProducts);
      // console.log(await Product.fromLi(page.allProducts[0]));
      const expectedProducts =  productsBefore.filter(h => h.name !== newProductName);
      expect(productsAfter).toEqual(expectedProducts);
      // expect(page.selectedProductSubview.isPresent()).toBeFalsy();
    });

    it(`adds back ${targetProduct.name}`, async () => {
      const newProductName = 'Alice';
      const productsBefore = await toProductArray(getPageElts().allProducts);
      const numProducts = productsBefore.length;

      element(by.css('input')).sendKeys(newProductName);
      element(by.buttonText('add')).click();

      let page = getPageElts();
      let productsAfter = await toProductArray(page.allProducts);
      expect(productsAfter.length).toEqual(numProducts + 1, 'number of products');

      expect(productsAfter.slice(0, numProducts)).toEqual(productsBefore, 'Old products are still there');

      const maxId = productsBefore[productsBefore.length - 1].id;
      expect(productsAfter[numProducts]).toEqual({id: maxId + 1, name: newProductName});
    });

    it('displays correctly styled buttons', async () => {
      element.all(by.buttonText('x')).then(buttons => {
        for (const button of buttons) {
          // Inherited styles from styles.css
          expect(button.getCssValue('font-family')).toBe('Arial');
          expect(button.getCssValue('border')).toContain('none');
          expect(button.getCssValue('padding')).toBe('5px 10px');
          expect(button.getCssValue('border-radius')).toBe('4px');
          // Styles defined in products.component.css
          expect(button.getCssValue('left')).toBe('194px');
          expect(button.getCssValue('top')).toBe('-32px');
        }
      });

      const addButton = element(by.buttonText('add'));
      // Inherited styles from styles.css
      expect(addButton.getCssValue('font-family')).toBe('Arial');
      expect(addButton.getCssValue('border')).toContain('none');
      expect(addButton.getCssValue('padding')).toBe('5px 10px');
      expect(addButton.getCssValue('border-radius')).toBe('4px');
    });

  });

  describe('Progressive product search', () => {

    beforeAll(() => browser.get(''));

    it(`searches for 'Ma'`, async () => {
      getPageElts().searchBox.sendKeys('Ma');
      browser.sleep(1000);

      expect(getPageElts().searchResults.count()).toBe(4);
    });

    it(`continues search with 'g'`, async () => {
      getPageElts().searchBox.sendKeys('g');
      browser.sleep(1000);
      expect(getPageElts().searchResults.count()).toBe(2);
    });

    it(`continues search with 'e' and gets ${targetProduct.name}`, async () => {
      getPageElts().searchBox.sendKeys('n');
      browser.sleep(1000);
      let page = getPageElts();
      expect(page.searchResults.count()).toBe(1);
      let product = page.searchResults.get(0);
      expect(product.getText()).toEqual(targetProduct.name);
    });

    it(`navigates to ${targetProduct.name} details view`, async () => {
      let product = getPageElts().searchResults.get(0);
      expect(product.getText()).toEqual(targetProduct.name);
      product.click();

      let page = getPageElts();
      expect(page.productDetail.isPresent()).toBeTruthy('shows product detail');
      let product2 = await Product.fromDetail(page.productDetail);
      expect(product2.id).toEqual(targetProduct.id);
      expect(product2.name).toEqual(targetProduct.name.toUpperCase());
    });
  });

  async function dashboardSelectTargetProduct() {
    let targetProductElt = getPageElts().topProducts.get(targetProductDashboardIndex);
    expect(targetProductElt.getText()).toEqual(targetProduct.name);
    targetProductElt.click();
    browser.waitForAngular(); // seems necessary to gets tests to pass for toh-pt6

    let page = getPageElts();
    expect(page.productDetail.isPresent()).toBeTruthy('shows product detail');
    let product = await Product.fromDetail(page.productDetail);
    expect(product.id).toEqual(targetProduct.id);
    expect(product.name).toEqual(targetProduct.name.toUpperCase());
  }

  async function updateProductNameInDetailView() {
    // Assumes that the current view is the product details view.
    addToProductName(nameSuffix);

    let page = getPageElts();
    let product = await Product.fromDetail(page.productDetail);
    expect(product.id).toEqual(targetProduct.id);
    expect(product.name).toEqual(newProductName.toUpperCase());
  }

});

function addToProductName(text: string): promise.Promise<void> {
  let input = element(by.css('input'));
  return input.sendKeys(text);
}

function expectHeading(hLevel: number, expectedText: string): void {
  let hTag = `h${hLevel}`;
  let hText = element(by.css(hTag)).getText();
  expect(hText).toEqual(expectedText, hTag);
};

function getProductAEltById(id: number): ElementFinder {
  let spanForId = element(by.cssContainingText('li span.badge', id.toString()));
  return spanForId.element(by.xpath('..'));
}

function getProductLiEltById(id: number): ElementFinder {
  let spanForId = element(by.cssContainingText('li span.badge', id.toString()));
  return spanForId.element(by.xpath('../..'));
}

async function toProductArray(allProducts: ElementArrayFinder): Promise<Product[]> {
  let promisedProducts = await allProducts.map(Product.fromLi);
  // The cast is necessary to get around issuing with the signature of Promise.all()
  return <Promise<any>> Promise.all(promisedProducts);
}
