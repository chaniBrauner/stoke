import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Observable, of} from 'rxjs';
import {catchError, map, tap} from 'rxjs/operators';
import {ProductDetails} from './productDetails';
import {Injectable} from '@angular/core';

import {MessageService} from '../message.service';

const httpOptions = {
  headers: new HttpHeaders({'Content-Type': 'application/json'})
};

@Injectable({providedIn: 'root'})
export class ProductDetailsService {

  private productsUrl = 'http://localhost:5045/stoke/productDetails';  // URL to web api
  constructor(
    private http: HttpClient,
    private messageService: MessageService) {
  }

  /** Log a ProductService message with the MessageService */
  private log(message: string) {
    this.messageService.add(`ProductService: ${message}`);
  }

  /** GET products from the server */

  getSoldProducts(): Observable<ProductDetails[]> {
    return this.http.get<ProductDetails[]>(this.productsUrl + '/sold').pipe(
      tap(_ => this.log('fetched products')),
      catchError(this.handleError('getProducts', []))
    );
  }
  buyProduct(id: string): Observable<ProductDetails> {
    return this.http.post<ProductDetails>(`${this.productsUrl}productDetails/buy/${id}`, httpOptions).pipe(
      tap((newProduct: ProductDetails) => this.log(`added product w/ id=${newProduct.product._id}`)),
      catchError(this.handleError<ProductDetails>('addProduct'))
    );
  }
  /**
   * Handle Http operation that failed.
   * Let the app continue.
   * @param operation - name of the operation that failed
   * @param result - optional value to return as the observable result
   */
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      this.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }

}
