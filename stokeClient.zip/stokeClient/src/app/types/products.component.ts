import {Component, OnInit} from '@angular/core';

import {Product} from './product';
import {ProductService} from './products.service';

@Component({
  selector: 'app-product',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  products: Product[] = [];
  sold: Product[] = [];

  constructor(private productService: ProductService) {
  }

  ngOnInit() {
    this.getProducts();
    this.getSoldProduct();
  }

  getProducts(): void {
    this.productService.getProducts().subscribe(products => {
        this.products = products;
      }
    );
  }

  getSoldProduct(): void {
    this.productService.getSoldProducts().subscribe(products => {
        this.sold = products;
      }
    );
  }

  add(product: Product): void {
    this.sold.push(product);
    this.productService.buyProduct(product._id).subscribe();
  }

  delete(product: Product): void {
    this.products = this.products.filter(h => h !== product);
    this.productService.deleteProduct(product).subscribe();
  }

}
