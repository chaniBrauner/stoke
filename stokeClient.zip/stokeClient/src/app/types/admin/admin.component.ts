import {Component, OnInit} from '@angular/core';

import {Product} from '../product';
import {ProductDetailsService} from '../productDetails.service';
import {ProductDetails} from '../productDetails';


@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  sold: ProductDetails[];
  doughnutChartLabels: string[];
  doughnutChartData: number[];
  doughnutChartType = 'doughnut';

  constructor(private productService: ProductDetailsService) {
  }

  public chartClicked(e: any): void {
    console.log(e);
  }

  public chartHovered(e: any): void {
    console.log(e);
  }

  ngOnInit() {
    this.getSoldProducts();
  }

  getSoldProducts(): void {
    this.productService.getSoldProducts().subscribe(products => {
        let total = 0;
        products.map(obj => {
          total += obj.sold;
        });
        const lables = [];
        const data = [];
        products.map(obj => {
          lables.push(obj.product.name);
          const percentage = parseInt(parseFloat('' + (obj.sold / total) * 100).toFixed(2), 0);
          data.push(percentage);
        });
        this.doughnutChartLabels = lables;
        this.doughnutChartData = data;
        this.chartHovered('e');
        this.sold = products;
      }
    );
  }
}
