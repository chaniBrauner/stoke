import {Product} from './product';

export class ProductDetails {
  id: string;
  product: Product;
  sold: number;
}
