import {Category} from './category';

export class Product {
  _id: string;
  name: string;
  price: number;
  category: Category;
}
