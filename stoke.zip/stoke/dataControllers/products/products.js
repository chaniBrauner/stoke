const mongoose = require('mongoose'),
    productModel = require('../../models/product');
let list = [{name: "Toffee", price: "4.5", categoryId: "5c72b75e95b85f353cb64cb3"},
    {name: "candy", price: "3.5", categoryId: "5c72b75e95b85f353cb64cb3"},
    {name: "Bagel", price: "4.5", categoryId: "5c72b75e95b85f353cb64cb5"},
    {name: "Bamba", price: "4.5", categoryId: "5c72b75e95b85f353cb64cb5"},
    {name: "Belgian chocolate", price: "20", categoryId: "5c72b75e95b85f353cb64cb4"},
    {name: "Egg", price: "20", categoryId: "5c72b75e95b85f353cb64cb4"},
    {name: "Sour candy", price: "40", categoryId: "5c72b75e95b85f353cb64cb6"},
    {name: "Sour gum", price: "35", categoryId: "5c72b75e95b85f353cb64cb6"}];

 function createNew() {
    list.forEach(function (doc) {
        products.addProduct(doc.name, doc.price, doc.categoryId, null, function (data) {
            console.log('create product: ' + JSON.stringify(data));
        })
    })
};
const products = {
    getProducts: function (conditions, callback, callbackError) {
        productModel.find().lean().exec(function (err, data) {
            if (err) {
                callbackError(err);
                return;
            }
            if (!data) {
                callbackError({statusCode: 404, err: 'noData'});
                return;
            }
            callback(data);
        });
    },
    getProductById: function (productId, conditions, callback, callbackError) {
        let query = {
            id: productId,
        };
        productModel.findById(query, function (err, data) {
            if (err) {
                callbackError(err);
                return;
            }
            if (!data) {
                callbackError({statusCode: 404, err: 'noData'});
                return;
            }
            callback({product: data});
        });
    },
    addProduct: function (name, price, categoryId, conditions, callback, callbackError) {
        let query = {
            name: name,
            price: price,
            category: categoryId
        };
        productModel.create(query, function (err, data) {
            if (err) {
                callbackError(err);
                return;
            }
            if (!data) {
                callbackError({statusCode: 404, err: 'noData'});
                return;
            }
            callback({product: data});
        });
    },
    buyProduct: function (name, price, categoryId, conditions, callback, callbackError) {
        let query = {
            name: name,
            price: price,
            category: categoryId
        };
        productModel.create(query, function (err, data) {
            if (err) {
                callbackError(err);
                return;
            }
            if (!data) {
                callbackError({statusCode: 404, err: 'noData'});
                return;
            }
            callback({product: data});
        });
    },

};
//createNew();
module.exports = products;

