const express = require('express'),
    router = express.Router(),
    products = require('./products');

router.get('/',function (req, res, next) {
    products.getProducts( {},  (data) => {
        res.json(data);
    }, (error) => {
        res.status(error.statusCode).json(error.err || error);
    })
});

router.route('/getProductById/:id').get(function (req, res, next) {
    products.getProductById(req.params.id, req.body.conditions,  (data) => {
        res.json(data);
    }, (error) => {
        res.status(error.statusCode).json(error.err || error);
    })
});



router.route('/addProduct').post(function (req, res, next) {
    products.addProduct(req.body.id, req.body.conditions,  (data) => {
        res.json(data);
    }, (error) => {
        res.status(error.statusCode).json(error.err || error);
    })
});

module.exports = router;
