const express = require('express'),
    router = express.Router(),
    products = require('./productDetails');



router.route('/sold').get(function (req, res, next) {
    products.getLeadProducts(null,  (data) => {
        res.json(data);
    }, (error) => {
        res.status(error.statusCode).json(error.err || error);
    })
});

router.route('/buy/:id').post(function (req, res, next) {
    products.buyProductById(req.params.id,  (data) => {
        res.json(data);
    }, (error) => {
        res.status(error.statusCode).json(error.err || error);
    })
});




module.exports = router;
