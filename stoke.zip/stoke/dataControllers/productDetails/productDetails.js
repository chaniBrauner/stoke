const mongoose = require('mongoose'),
    productModel = require('../../models/productDetails');
const productDetails = {
    getLeadProducts: function (conditions, callback, callbackError) {
        productModel.find().populate('product')
            .sort({'sold': -1})
            .limit(5).lean().exec(function (err, data) {
            if (err) {
                callbackError(err);
                return;
            }
            if (!data) {
                callbackError({statusCode: 404, err: 'noData'});
                return;
            }
            callback(data);

        });
    },
    buyProductById: function (productId, callback, callbackError) {
        let query = {
            product: productId
        };
        let update = {
            product: productId,
            $inc: {
                sold: 1
            }
        };
        let options = {upsert: true, new: true};
        productModel.findOneAndUpdate(query, update, options, function (err, data) {
            if (err) {
                callbackError(err);
                return;
            }
            if (!data) {
                callbackError({statusCode: 404, err: 'noData'});
                return;
            }
            callback(data);
        });
    },

};

module.exports = productDetails;

