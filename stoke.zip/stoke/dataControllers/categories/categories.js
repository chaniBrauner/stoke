const mongoose = require('mongoose'),
    categoryModel = require('../../models/cutegory');
const products = {
    addCategory:function (name, callback, callbackError) {
        let query = {
            name:name
        };
        categoryModel.create(query, function (err, data) {
            if (err) {
                callbackError(err);
                return;
            }
            if (!data) {
                callbackError({statusCode: 404, err: 'noData'});
                return;
            }
            callback({categories: data});
        });
    }

};

module.exports = products;

