const express = require('express'),
    router = express.Router(),
    categories = require('./categories');


let categoryList = [{"name": "sweets"},
    {"name": "chocolate"},
    {"name": "salt"}, {"name": "sour"}];
 function addCategory() {
    categoryList.forEach(function (cat) {
        categories.addCategory(cat.name, (data) => {
            console.log('create: ' + JSON.stringify(data))
        })
    })
}
router.route('/addProduct').post(function (req, res, next) {
    categories.addCategory(req.params.id, req.body.conditions, (data) => {
        res.json(data);
    }, (error) => {
        res.status(error.statusCode).json(error.err || error);
    })
});

module.exports = router;
