const express = require('express'),
    router = express.Router(),
    products = require('./stokes');

router.route('/getProductById/:id').post(function (req, res, next) {
    products.getProductById(req.params.id, req.body.conditions,  (data) => {
        res.json(data);
    }, (error) => {
        res.status(error.statusCode).json(error.err || error);
    })
});

router.route('/:id/flowsPie').post(function (req, res, next) {
    analytics.getFlowsPie(req.params.id, req.body.conditions, (data) =>{
        res.json(data);
    }, (error) => {
        res.status(error.statusCode).json(error.err || error);
    })
});

router.route('/:id/succeededPie').post(function (req, res, next) {
    analytics.getSucceededPie(req.params.id, req.body.conditions, (data) => {
        res.json(data);
    }, (error) => {
        res.status(error.statusCode).json(error.err || error);
    })
});

router.route('/:id/satisfiedPie').post(function (req, res, next) {
    analytics.getSatisfiedPie(req.params.id, req.body.conditions, (data) => {
        res.json(data);
    }, (error) => {
        res.status(error.statusCode).json(error.err || error);
    })
});

router.route('/:orgId/chats').post(function (req, res, next) {
    analytics.getChats(req.params.orgId, req.body, (data) => {
        res.json(data);
    }, (error) => {
        res.statusCode(error.statusCode || 500).json(error);
    })
});
router.route('/chat/:id').get(function (req, res, next) {
    analytics.getSingleChat(req.params.id, (data) => {
        res.json(data);
    }, (error) => {
        res.statusCode(error.statusCode || 500).json(error);
    })
});

module.exports = router;
