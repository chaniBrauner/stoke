const mongoose = require('mongoose'),
    productModel = require('../../models/product');
const stokes = {
    getProductById: function (productId, conditions, callback, callbackError) {
        let query = {
            id:productId,
        };
       productModel.findById(query, function (err, data) {
            if (err) {
                callbackError(err);
                return;
            }
            if (!data) {
                callbackError({statusCode: 404, err: 'noData'});
                return;
            }
            callback({product: data});
        });
    }
};

module.exports = stokes;

