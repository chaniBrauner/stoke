const mongoose = require('mongoose'),
    config = require('config');

let dbUri = config.get('dbConfig.uri');

mongoose.connect(dbUri, function (err, res) {
    if (err) {
        console.error('ERROR connecting to: ' + dbUri + '. ' + err);
    } else {
        console.log('Succeeded connected to: ' + dbUri);
    }
});
