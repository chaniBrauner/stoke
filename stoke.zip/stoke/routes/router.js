"use strict";
const mongoose = require('mongoose');
const express = require("express"),
    router = express.Router(),
    products = require('../dataControllers/products/products.controller'),
    categories = require('../dataControllers/categories/categories.controller'),
    productDetails = require('../dataControllers/productDetails/productDetails.controller'),
    stokes = require('../dataControllers/stokes/stokes.controller');

router.use('/products', products);
router.use('/categories', categories);
router.use('/productDetails', productDetails);
router.use('/stokes', stokes);

router.get('/health', function (req, res, next) {
    if (mongoose.connection.readyState == 1) {
        res.send('ok');
    } else {
        res.status(500);
    }
});

module.exports = router;
