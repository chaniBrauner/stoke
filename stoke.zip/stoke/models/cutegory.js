"use strict";
const mongoose = require('mongoose'),
    autopopulate = require('mongoose-autopopulate'),
    Schema = mongoose.Schema;

const category = new mongoose.Schema({
    name: {
        type: String,
        required: true
    }
});


category.plugin(autopopulate);
module.exports = mongoose.model('category', category);