"use strict";
const mongoose = require('mongoose'),
    autopopulate = require('mongoose-autopopulate'),
    Schema = mongoose.Schema;

const productDetails = new mongoose.Schema({
    product: {
        type: Schema.ObjectId,
        ref: 'product',
        autopopulate: true
    },
    sold: Number
});


productDetails.plugin(autopopulate);
module.exports = mongoose.model('productDetails', productDetails);
