"use strict";
const mongoose = require('mongoose'),
    autopopulate = require('mongoose-autopopulate'),
    Schema = mongoose.Schema;

const stoke = new mongoose.Schema({
    products: [{
        type: Schema.ObjectId,
        ref: 'productDetails',
        autopopulate: true
    }]
});


stoke.plugin(autopopulate);
module.exports = mongoose.model('stoke', stoke);