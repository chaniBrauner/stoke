"use strict";
const mongoose = require('mongoose'),
    autopopulate = require('mongoose-autopopulate'),
    Schema = mongoose.Schema;

const product = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    price: Number,
    category: {
        type: Schema.ObjectId,
        ref: 'category',
        autopopulate: true
    }
});


product.plugin(autopopulate);
module.exports = mongoose.model('product', product);